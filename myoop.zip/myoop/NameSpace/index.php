<?php
include_once('Controller/Java.php');

use HABIB\Java;

$hh = new Java;
$hh->p();

?>