<?php
namespace HABIB;

class Java{
    public function p(){
        echo "hello world";
    }
}

?>