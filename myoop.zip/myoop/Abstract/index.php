<?php

// abstract class Abs{
//     abstract function Name();
// }

// class My extends Abs{
//     function Name(){
//         echo "My Name Is Habib <br/>";
//     }
// }

// class Rishat extends Abs{
//     function Name(){
//         echo "Name Is Rishat <br/>";
//     }
// }

// $obj = new My();
// $obj->Name();

// $rishat = new Rishat();
// $rishat->Name();



interface Country{
    public function BD();
}

class Bangladesh implements Country{
    public function BD(){
        echo "Bangladesh Is our Motherland";
    }
}

$obj = new Bangladesh;
$obj->BD();


?>