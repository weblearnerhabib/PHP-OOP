<?php

#single line comment

// Single line comments 2

/* Multiple 

Line Comments

*/

echo "comments in php";


?>