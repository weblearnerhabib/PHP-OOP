<?php

/*

define('HABIB', "Value of Constant");
define("Adnan", "HABIB");

echo HABIB. "<br/>";
echo constant("Adnan");

*/

// nested constant

define('name', "Adnan Habib");
define('nes', 'name');

echo nes. "<br/>";

echo constant(nes);


?>