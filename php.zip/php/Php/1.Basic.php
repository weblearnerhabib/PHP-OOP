<?php

$name= "Adnan";
$age = 23;

echo "My Name is: $name and i'm $age years old <br/><hr/>";

echo 'My Name is: '.$name.' and i am '.$age.' years old ';


?>