<?php
$bewafa = "Trust";
while($bewafa = "Trust"){
  echo "Psycho";
}

?>