<?php

$first = "This value will be show for nested variable";
$second = "first";
$third= "second";

echo $$$third;

?>