<?php 
require_once('classes/Users.php');
$obj = new Users();

$id= $_GET['id'];

if(isset($id)){
    $obj->Delete($id);
}

?>