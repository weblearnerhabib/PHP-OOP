<?php

class Users{
    private $connectDb;
    public function __construct(){
        define("HOST","localhost");
        define("USER","root");
        define("PASS",'');
        define("DBNAME","adnan");
        $this->connectDb = mysqli_connect(HOST,USER,PASS,DBNAME);
    }
    // Construction Function End

    // insert form data to database
    public function Insert($info){
        $infoData = $info;
        $name= ucwords($infoData['Name']);
        $mail= strtolower($infoData['Mail']);
        $password= $infoData['Password'];
        $query= "INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES (NULL, '$name', '$mail', '$password')";
        $sql = mysqli_query($this->connectDb, $query);
        if($sql) {
            header("Location:index.php");
        }
    } // insert Data End

    // Show Data From Database Table to Index.php Table
    public function Show(){
        $query = "SELECT * FROM `users`";
        return $result = mysqli_query($this->connectDb, $query);
    }

    public function Delete($id){
        $query ="DELETE FROM `users` WHERE id='$id'";
        $delete = mysqli_query($this->connectDb, $query);
        if($delete){
            header("Location:index.php");
        }
    }
}


?>