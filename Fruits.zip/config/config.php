<?php
class ConnectionDb{
    protected $dbConnection;
    public function __construct(){
      $db = $this->dbConnection = new mysqli("localhost","root",'',"hr");
    }
}
?>