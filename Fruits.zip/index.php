<!-- PHP Code Area -->
<?php
    include_once('classes/fruits.php');
    $Hrobj = new Fruits;

    // Get Data from Form
    if(isset($_POST['fruits_Submit'])){
        $dataFruits = $_POST;
        $Hrobj->InsertFruits($dataFruits);
        
    }

?>

<!-- header Include -->
<?php include_once('templates/header.php')?>

<!-- Main Content Area -->
<div class="Fruits mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <table class="table table-bordered">
                    <thead class="text-center">
                        <tr>
                            <th> Fruits Name </th>
                            <th> Fruits Qty </th>
                            <th> Image </th>
                            <th> Fruits Price </th>
                            <th> Action </th>
                        </tr>
                    </thead>

                    <?php
                        $data = $Hrobj->ShowFruits();
                        while($info= mysqli_fetch_assoc($data)){
                    ?>
                    <tbody class="text-center">
                        <tr>
                            <td> <?php echo $info['fruitsname']; ?> </td>
                            <td> <?php echo $info['fruitsqty']; ?> </td>
                            <td>
                                <img width="70px" src="assets/fruits/<?php echo $info['fruitsphoto'];?>">
                            </td>
                            <td> <?php echo $info['fruitsprice']; ?> </td>
                            <td>
                                <a href="edit.php?id=<?php echo $info['fruitsid'];?>" class="btn btn-sm btn-warning"> Edit </a>
                                <a href="delete.php?id=<?php echo $info['fruitsid'];?>" class="btn btn-sm btn-danger"> Delete </a>
                            </td>
                        </tr>
                    </tbody>

                    <?php   
                        }
                    ?>

                </table>
            </div> <!-- col-md-8 end -->

            <!-- Button trigger modal -->
            <div class="col-md-6 offset-md-3 shadow p-3 mt-3 mb-5">
                
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="form-group my-2">
                        <input type="text" name="fruits_Name" placeholder="Enter Fruits Name" class="form-control" required>
                    </div>
                    <div class="form-group my-2">
                        <input type="text" name="fruits_Qty" placeholder="Fruits Quantity" class="form-control" required>
                    </div>
                    <div class="form-group my-2">
                        <input type="file" name="fruits_Image" class="form-control" required>
                    </div>
                    <div class="form-group my-2">
                        <input type="number" name="fruits_Price" placeholder="Fruits Price" class="form-control" required>
                    </div>
                    <div class="form-group my-2">
                        <input type="submit" name="fruits_Submit" class="btn btn-success" value="Insert Fruits">
                    </div>
                </form>

            </div>

        </div> <!-- Row --->
    </div>
</div>





<!-- Main Content End -->

<!-- footer Include -->
<?php include_once('templates/footer.php');?>