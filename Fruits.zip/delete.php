<!-- PHP Code Area -->
<?php
    include_once('classes/fruits.php');
    $Hrobj = new Fruits;

    $id = $_GET['id'];
    if(isset($id)){
        $Hrobj->DeleteFruits($id);
        header("location: index.php");
    }

?>