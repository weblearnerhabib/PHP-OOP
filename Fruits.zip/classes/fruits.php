<?php
include_once('config/config.php');
class Fruits extends ConnectionDb{
    // Insert Fruits 
    public function InsertFruits($dataFruits){
        $fName = $dataFruits['fruits_Name'];
        $fQty = $dataFruits['fruits_Qty'];
            // Fruits Image
        $imgName = $_FILES['fruits_Image']['name'];
        $imgTempLoc = $_FILES['fruits_Image']['tmp_name'];
        $fPrice = $dataFruits['fruits_Price'];

        $sql = "INSERT INTO `fruitstable` (`fruitsname`, `fruitsqty`, `fruitsphoto`, `fruitsprice`) VALUES ('$fName', '$fQty', '$imgName', '$fPrice')";
        $query = $this->dbConnection->query($sql);

        if($query){
            move_uploaded_file($imgTempLoc, "assets/fruits/".$imgName);
            header("Location: index.php"); }
    }


    // Show
    public function ShowFruits(){
        $sql = "SELECT * FROM `fruitstable`";
        return $data = $this->dbConnection->query($sql);
    }

    // Delete 
    public function DeleteFruits($id){
        $un = "SELECT * FROM `fruitstable` WHERE fruitsid = $id";
        $query = $this->dbConnection->query($un);

        $fnameAssoc = mysqli_fetch_assoc($query);
        $frutName = $fnameAssoc['fruitsphoto'];

        $sql = "DELETE FROM `fruitstable` WHERE fruitsid =$id";
        $query = $this->dbConnection->query($sql);
        if($query){
            unlink("assets/fruits/".$frutName);
        }
    }

    // Edit
    public function EditFruits($id){
      return $this->dbConnection->query("SELECT * FROM `fruitstable` WHERE fruitsid = $id");
    }

    // Update
    public function UpdateFruits($data,$id){
       $nam = $data['fruits_Name'];
       $qty = $data['fruits_Qty'];
       $prc = $data['fruits_Price'];
       
       $sql = "UPDATE `fruitstable` SET `fruitsname`='$nam',`fruitsqty`='$qty',`fruitsprice`='$prc' WHERE fruitsid = $id";
        $up = $this->dbConnection->query($sql);

        if($up){
            header("location: index.php");
        }

    }

}
?>