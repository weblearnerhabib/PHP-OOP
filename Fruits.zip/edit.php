<!-- PHP Code Area -->
<?php
    include_once('classes/fruits.php');
    $Hrobj = new Fruits;

    $id = $_GET['id'];

    if(isset($_GET['id'])){
        $Hrobj->EditFruits($id);
        $objToArr = mysqli_fetch_assoc($Hrobj->EditFruits($id));

        if(isset($_POST['updateF_Submit'])){
            $Hrobj->UpdateFruits($_POST,$id);
        }
    }
    
?>

<!-- header Include -->
<?php include_once('templates/header.php')?>

<!-- Main Content Area -->
<div class="Fruits mt-5">
    <div class="container">
        <div class="row">

            <div class="col-md-6 offset-md-3 shadow p-3 mt-3 mb-5">
                <h2 class="text-center display-3 py-2 mb-5 text-info"> Update Fruits </h2>
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="form-group my-2">
                        <input value="<?php echo $objToArr['fruitsname']?>" type="text" name="fruits_Name" placeholder="Enter Fruits Name" class="form-control" required>
                    </div>
                    <div class="form-group my-2">
                        <input value="<?php echo $objToArr['fruitsqty']?>" type="text" name="fruits_Qty" placeholder="Fruits Quantity" class="form-control" required>
                    </div>
                    <div class="form-group my-2">
                        <input value="<?php echo $objToArr['fruitsprice']?>" type="number" name="fruits_Price" placeholder="Fruits Price" class="form-control" required>
                    </div>
                    <div class="form-group my-2">
                        <input type="submit" name="updateF_Submit" class="btn btn-info text-white" value="Update Fruits">
                    </div>
                </form>

            </div>

        </div> <!-- Row --->
    </div>
</div>





<!-- Main Content End -->

<!-- footer Include -->
<?php include_once('templates/footer.php');?>