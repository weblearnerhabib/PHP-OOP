<?php

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> PHP CRUD - OOP </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Aladin&display=swap');
        h1,h2,h3{ font-family: 'Aladin', cursive; }
    </style>
  </head>
  <body>
    
    <!-- header area -->
    <header class="text-center py-3 bg-success">
        <h1 class="text-white"> Welcome to Adnan Habib Planet </h1>
    </header>

    <!-- table of users -->
    <div class="container">
        <div class="row">

            <div class="col-md-8 mt-5">
                <table class="table table-bordered text-center table-hover">
                    <thead>
                      <tr>
                        <th>#No</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>John</td>
                        <td>Doe</td>
                        <td>john@example.com</td>
                        <td>
                            <a href="" class="btn btn-sm btn-warning"> Edit </a>
                            <a href="" class="btn btn-sm btn-danger"> Delete </a>
                        </td>
                      </tr>
                      <tr>
                        <td>John</td>
                        <td>Doe</td>
                        <td>john@example.com</td>
                        <td>
                            <a href="" class="btn btn-sm btn-warning"> Edit </a>
                            <a href="" class="btn btn-sm btn-danger"> Delete </a>
                        </td>
                      </tr>
                      <tr>
                        <td>John</td>
                        <td>Doe</td>
                        <td>john@example.com</td>
                        <td>
                            <a href="" class="btn btn-sm btn-warning"> Edit </a>
                            <a href="" class="btn btn-sm btn-danger"> Delete </a>
                        </td>
                      </tr>
                    </tbody>
                  </table>
            </div>


            <div class="col-md-4 mt-5">
                
                <form class="form-control shadow border-0 p-5" action="" method="POST">
                    <h2 class="pt-2 text-center text-success"> Insert User Data </h2>
                    <input type="text" name="Name" placeholder="Type Name" class=" mb-3 mt-3 form-control" required>
                    <input type="email" name="Mail" placeholder="Type Email" class=" mb-3 form-control" required>
                    <input type="password" name="password" placeholder="Type Password" class=" mb-3 form-control" required>
                    <input type="submit" name="subBtn" value="Insert Data" class="w-100 btn btn-success btn-sm mb-3">
                </form>
            </div>

        </div>
    </div>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  </body>
</html>