<?php

class PENCILBOX{

	public $names;

	public function Hi(){
		echo "Hi ";
	}

	public function details(){
		echo " You are student of PHP Batch 15 <hr>";
	}
}


$students = new PENCILBOX;

$students->hi();
$students->names =" Habibur";
echo $students->names;
$students->details();



$students2 = new PENCILBOX;

$students2->hi();
$students2->names =" লুতফুল্লাহিল";
echo $students2->names;
$students2->details();



$soyeb = new PENCILBOX;

$soyeb->hi();
echo $soyeb->names =" শোয়েব বিন কামাল";
$soyeb->details();