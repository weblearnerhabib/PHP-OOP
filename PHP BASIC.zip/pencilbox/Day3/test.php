<?php

// class HABIB{
//     public $varHabib;
//     private $jobDetails;

//     public function habibMethod(){
//         echo "My Age is only 24 Years <hr>";
//     }

//     public function DetailsMe(){
//         echo $this->varHabib = "<h4> My Name Is Habib </h4>";
//     }

//     public function JobDetails(){
//        echo $this->jobDetails = "<h5> I work with Freelancer.com Since 2019 as a Web Developer";
//     }
// }

// $outPut = new HABIB();

// $outPut->DetailsMe();
// $outPut->habibMethod();
// $outPut->JobDetails();


// আর্গুমেন্ট পাঠানো এবং প্যারামিটার হিসাবে রিসিভ করা 

class Habib{
    public $name;
    public function printMe($n){
        $xx = $this->name =$n;
        
        echo "$xx is a good boy";
    }
}

$outPut = new Habib();
$outPut->printMe("Habib");


?>