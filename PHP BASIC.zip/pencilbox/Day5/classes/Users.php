<?php

class Users{
	public $connectDb;
	
	public function __construct(){
		define("HOST", "localhost");
		define("USER", "root");
		define("PASS", "");
		define("DB", "day6");
		$con = $this->connectDb = mysqli_connect(HOST,USER,PASS,DB);
	}

	public function INSERTDATA($hashData){
		$info = $hashData;
		$name = ucwords($info['userName']);
		$mail = strtolower($info['userMail']);
		$code = $info['userPass'];

		$sql = "INSERT INTO `usertable` (`id`, `name`, `email`, `password`) VALUES (null, '$name', '$mail', '$code')";
		$temp = mysqli_query($this->connectDb, $sql);
		if ($temp) {
			header('location:index.php');
		}
	}

	public function ShowData(){
		$sql = "SELECT * FROM `usertable`";
		return $data = mysqli_query($this->connectDb, $sql);
	}


	public function DeleteData($id){
		$sql = "DELETE FROM `usertable` WHERE id='$id'";
		$del = mysqli_query($this->connectDb, $sql);

		if ($del) {
			header('location: index.php');
		}
	}

}


?>