<?php
require_once('classes/Users.php');
$obj= new Users;

if (isset($_GET['id'])) {
	$id = $_GET['id'];
	$obj->DeleteData($id);
}


?>