<?php
// Inheritance
class ParentClass{
    protected $myName = "Test MyName";

    public function __construct(){
        echo "<hr> Parent hello world <br>";
    }
}

class ChildClass extends ParentClass{
    public function habibur($ay_hay){
        $this->myNam = $ay_hay;

        echo "$this->myNam hello habibur";
    }
}

// without argument
class ChildClass2 extends ParentClass{
    
    public function habibur(){
        echo "$this->myName hello habibur";
    }
}

$xx = new ChildClass();
$xx->habibur("আয় হায়");


// without argument
$zz = new ChildClass2();
$zz->habibur();

// আর্গুমেন্ট না পাঠালে প্যারেন্ট ক্লাসের Protected Property এক্সেস করতে দিচ্ছে।  
// আর্গুমেন্ট পাঠালে $this->differentName ভ্যারিয়েবল তৈরি করতেও দিচ্ছে। 

// Note: শুধুমাত্র Property এক্সেস করতে দিচ্ছে। method এক্সেস করতে দিচ্ছে না 