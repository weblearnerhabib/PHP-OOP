<?php
if(isset($_POST['subBtn'])){
    $fName = $_POST['firstName'];
    $lName = $_POST['lastName'];
    $company = $_POST['companyName'];
    $cmail = $_POST['companyEmail'];
    $job = $_POST['jobTitle'];
    $country = $_POST['country'];
}

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PHP ISSET value show in table</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  </head>
  <body>

  <div class="container">
    <div class="row text-center">
        <h2> Let's Start a conversation</h2>
    </div>

    <div class="col-md-6 offset-md-3">
        <form action="" method="POST">
            <div class="form-group">
                <label for="fn" class="form-label"> First Name </label>
                <input type="text" class="form-control" name="firstName" id="fn">
            </div>

            <div class="form-group">
                <label for="ln" class="form-label"> Last Name </label>
                <input type="text" class="form-control" name="lastName" id="ln">
            </div>

            <div class="form-group">
                <label for="cn" class="form-label"> Company Name </label>
                <input type="text" class="form-control" name="companyName" id="cn">
            </div>

            <div class="form-group">
                <label for="cmail" class="form-label"> Company Email </label>
                <input type="text" class="form-control" name="companyEmail" id="cmail">
            </div>
            
            <div class="form-group">
                <label for="jobTitle" class="form-label"> Job Title </label>
                <input type="text" class="form-control" name="jobTitle" id="jobTitle">
            </div>
            
            <div class="form-group">
                <label for="country" class="form-label"> Country </label>
                <select name="country" id="country" class="form-control">
                    <option value="" class="form-control"> Select Country </option>
                    <option value="Bangladesh" class="form-control"> Bangladesh </option>
                    <option value="Pakistan" class="form-control"> Pakistan </option>
                </select>
            </div>
            
            <div class="form-group">
                <br>
                <input type="submit" value="Send Message" name="subBtn" class="btn btn-primary">
                <br><br>
            </div>

        </form>
    </div>

    <div class="row">
        <div class="col-md-8 offset-md-2">
            <table class="table table-bordered">
                <tr>
                    <th> First Name </th>
                    <th> Last Name </th>
                    <th> Company Name </th>
                    <th> Company Email </th>
                    <th> Job Title </th>
                    <th> Country </th>
                </tr>
                <tr>
                    <td> <?php if(isset($fName)){ echo $fName;}; ?></td>
                    <td> <?php if(isset($lName)){ echo $lName;}; ?> </td>
                    <td> <?php if(isset($company)){ echo $company;}; ?> </td>
                    <td> <?php if(isset($cmail)){ echo $cmail;}; ?> </td>
                    <td> <?php if(isset($job)){ echo $job;}; ?> </td>
                    <td> <?php if(isset($country)){ echo $country;}; ?> </td>
                </tr>
            </table>
        </div>
    </div>

  </div>
    
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  </body>
</html>