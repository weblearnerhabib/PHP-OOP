<?php
	if (isset($_POST['subBtn'])) {
		$userName = $_POST['name'];
		$userMail = $_POST['email'];
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<form action="" method="POST">
		<input type="text" name="name" placeholder="Type Your Name"> <br><br>
		<input type="email" name="email" placeholder="Type Your Email"><br><br>
		<input type="submit" name="subBtn" value="Login">
	</form>

	<h2 style="color: red;"> Name: <span style="color: black;">
		<?php
			if (isset($userName)) {
				echo $userName;
			}
		?>
	</span></h2>

	<h2 style="color: red;"> Email: <span style="color: black;">
		<?php
			if (isset($userMail)) {
				echo $userMail;
			}
		?>
	</span></h2>

</body>
</html>