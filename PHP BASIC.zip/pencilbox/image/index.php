<?php
    if(isset($_POST['subBtn'])){
        $imgName = $_FILES['img_file']['name'];
        $tempImage = $_FILES['img_file']['tmp_name'];

        move_uploaded_file($tempImage,"uploads/".$imgName);
    }
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
    <div class="container">
        <div class="row">
            <div class="col-md-8 shadow py-4 mt-5">
                <h3> Form Data </h3>
                <form action="" method="POST" enctype="multipart/form-data">
                    <input type="text" placeholder="Enter Name" class="form-control mb-4">
                    <input type="file" name="img_file" class="form-control mb-4">
                    <input type="submit" name="subBtn" class="btn btn-dark text-white" value="Submit Data">
                </form>
            </div>

        <div class="col-md-4 shadow py-4 mt-5">
            <img src="uploads/<?php echo $imgName;?>" class="img-fluid">
        </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>