<?php
	
   // $number ="9";

// 	switch ($number) {
// 		case '1':
// 			echo "Send Money";
// 			break;
// 		case '2':
// 			echo "Send Money to Non Bkash User";
// 			break;
// 		case '3':
// 			echo "Mobile Recharge";
// 			break;
// 		case '4':
// 			echo "Payment";
// 			break;
// 		case '5':
// 			echo "CashOut";
// 			break;
// 		case '6':
// 			echo "Bill Pay";
// 			break;
// 		case '7':
// 			echo "Micro Finance";
// 			break;
// 		case '8':
// 			echo "Download Apps";
// 			break;
// 		case '9':
// 			echo "My Bkash";
// 			break;
// 		case '10':
// 			echo "Reset Pin";
// 			break;
		
// 		default:
// 			echo "Main Menu";
// 	}


$mark = 0;

switch ($mark) {
	
	case ($mark > 0 && $mark <33):
	echo "Fail";
	break;

	case ($mark>=80 && $mark<=100):
	echo "A+";
	break;

	case ($mark>=70 && $mark<=79):
	echo "A";
	break;
	
	case ($mark>=60 && $mark<=69):
	echo "A-";
	break;

	case ($mark>=50 && $mark<=59):
	echo "B";
	break;
	
	case ($mark>=40 && $mark<=49):
	echo "C";
	break;

	case ($mark>=33 && $mark<=39):
	echo "D";
	break;

	default:
	echo " Invalid Input ";
}

?>