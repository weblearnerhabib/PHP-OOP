<?php
    if(isset($_POST['subMe'])){
       $name = $_POST['user_name'];
       $mail = $_POST['user_email'];
       $pass = $_POST['user_password'];
       $age = $_POST['user_age'];
       $bio = $_POST['user_bio'];
       $job = $_POST['user_job'];
       $interest = $_POST['user_interest'];
    };
?>

<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up Form</title>
    <link href='https://fonts.googleapis.com/css?family=Nunito:400,300' rel='stylesheet' type='text/css'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="1.css">
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="" method="post">
                    <h1> Sign Up </h1>
                    <fieldset>
                        <legend><span class="number">1</span> Your Basic Info</legend>
                        <label for="name">Name:</label>
                        <input type="text" id="name" name="user_name">

                        <label for="email">Email:</label>
                        <input type="email" id="mail" name="user_email">

                        <label for="password">Password:</label>
                        <input type="password" id="password" name="user_password">

                        <label>Age:</label>
                        <input type="radio" value="Under 13" id="under_13" name="user_age"><label for="under_13"
                            class="light">Under 13</label><br>
                        <input type="radio" value="Over 13" id="over_13" name="user_age"><label for="over_13"
                            class="light">Over 13</label>

                    </fieldset>
                    <fieldset>

                        <legend><span class="number">2</span> Your Profile</legend>

                        <label for="bio">Bio:</label>
                        <textarea id="bio" name="user_bio"></textarea>



                        <label for="job">Job Role:</label>
                        <select id="job" name="user_job">
                            <optgroup label="Web">
                                <option value="Front-End Developer">Front-End Developer</option>
                                <option value="PHP Developer">PHP Developer</option>
                                <option value="Python Developer">Python Developer</option>
                                <option value="Web Designer">Web Designer</option>
                                <option value="Wordpress Developer">Wordpress Developer</option>
                            </optgroup>
                            <optgroup label="Mobile">
                                <option value="Android Developer">Android Developer</option>
                                <option value="IOS Developer">IOS Developer</option>
                                <option value="Mobile Designer">Mobile Designer</option>
                            </optgroup>
                        </select>

                        <label>Interests:</label>
                        <input type="checkbox" id="development" value="Development" name="user_interest"><label
                            class="light" for="development">Development</label><br>
                        <input type="checkbox" id="design" value="Design" name="user_interest"><label
                            class="light" for="design">Design</label><br>
                        <input type="checkbox" id="business" value="Business" name="user_interest"><label
                            class="light" for="business">Business</label>

                    </fieldset>

                    <button type="submit" name="subMe">Sign Up</button>

                </form>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="row">
            <div class="col-8 offset-2">
                <table class="table table-striped table-bordered p-2 text-center">
                    <thead>
                        <tr class="text-primary">
                            <th> NAME </th>
                            <th> Email </th>
                            <th> Password </th>
                            <th> Age </th>
                            <th> Bio </th>
                            <th> Job </th>
                            <th> Interest </th>
                        </tr>
                    </thead>
                    <tbody>
                    <tr>
                            <td> <?php if(isset($name)){ echo $name;};?></td>
                            <td> <?php if(isset($mail)){ echo $mail;};?> </td>
                            <td> <?php if(isset($pass)){ echo $pass;};?> </td>
                            <td> <?php if(isset($age)){ echo $age;};?> </td>
                            <td> <?php if(isset($bio)){ echo $bio;};?> </td>
                            <td> <?php if(isset($job)){ echo $job;};?> </td>
                            <td> <?php if(isset($interest)){ echo $interest;};?> </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous">
    </script>
</body>

</html>