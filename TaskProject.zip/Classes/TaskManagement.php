<?php
    class TaskManagement{
        protected $connectDb;

        // Database Connection
        public function __construct(){
            $this->connectDb = mysqli_connect("localhost","root","","taskmanagement");
        }

        // Insert Form Data to Database
        public function InsertData($taskData){
            $taskName = ucwords($taskData['newTask']);
            $taskDate = $taskData['taskDate'];
            $sql = "INSERT INTO `taskall` (`taskname`, `taskdate`) VALUES ('$taskName','$taskDate')";

            $query = mysqli_query($this->connectDb, $sql);
            if($query) header("location:index.php");
        }

        // Show Data From Database to Index Table
        public function ShowData(){
            $sql = "SELECT * FROM `taskall`";
            return $rawData = mysqli_query($this->connectDb, $sql);
            
        }

        // Delete Data
        public function DeleteData($id){
            $sql = "DELETE FROM `taskall` WHERE id=$id";
            mysqli_query($this->connectDb, $sql);
        }

        // Edit Task
        public function EditData($id){
            $query = "SELECT * FROM `taskall` WHERE id=$id";
            return $TaskDate = mysqli_query($this->connectDb,$query);
        }

        // Dpdate Task
        public function UpdateData($data,$id){
           $up_Task = ucwords($data['newTask']);
           $up_Task_Date = $data['taskDate'];
           
           $sql = "UPDATE `taskall` SET `taskname`='$up_Task',`taskdate`='$up_Task_Date' WHERE id = $id";
           $updateSql = mysqli_query($this->connectDb,$sql);
           if($updateSql) header("location: index.php");
        }


    }
?>