<?php
require_once('classes/TaskManagement.php');
$taskObj = new TaskManagement;

$id = $_GET['id'];

if(isset($_GET['id'])){
    $taskObj->EditData($id);

    $editReturnData = $taskObj->EditData($id);

    $editData = mysqli_fetch_assoc($editReturnData);

    if(isset($_POST['UpdateSubBtn'])){
        $taskObj->UpdateData($_POST,$id);
    }

}

?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Update Task </title>
    <link rel="stylesheet" href="Assets/bootstrap.min.css">
    </head>
  <body>

    <div class="FullTask py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-8 offset-md-2 shadow-sm">

            <div class="taskTitle text-center">
              <h2 class="text-primary pt-2"> Update Project Task </h2>
              <hr>
            </div>


            <!-- ADD TASK -->
            <div class="AddTask">
              <h3 class="pt-3 text-primary"> Update Task </h3>

              <form action="" method="POST" class="form-control mb-4">
                <div class="form-group my-2">
                  <label for="newTask"> Update Task </label>
                  <input type="text" name="newTask" id="newTask" class="form-control" placeholder="Add New Task" required value="<?php echo $editData['taskname']; ?>">
                </div>
                <div class="form-group my-2">
                  <label for="taskDate"> Update Date </label>
                  <input type="date" name="taskDate" id="taskDate" class="form-control" required value="<?php echo $editData['taskdate']; ?>">
                </div>
                <input type="submit" name="UpdateSubBtn" class="btn my-2 btn-dark" value="Update Task">
              </form>

            </div> <!-- Add TASK END -->

          </div> <!-- col-md-8 offset-md-2 -->
        </div> <!-- Row -->
      </div> <!-- Container -->
    </div>
    
    
  <script type="text/javascript" src="Assets/bootstrap.bundle.min.js"></script>
  </body>
</html>