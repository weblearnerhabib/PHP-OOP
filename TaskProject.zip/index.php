<?php
require_once('classes/TaskManagement.php');
$taskObj = new TaskManagement;

// Data Send with $_POST argument
if(isset($_POST['taskSubBtn'])){
  $taskObj->InsertData($_POST);
}

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Task Project</title>
    <link rel="stylesheet" href="Assets/bootstrap.min.css">
    </head>
  <body>

    <div class="FullTask py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-8 offset-md-2 shadow-sm">

            <div class="taskTitle text-center">
              <h2 class="text-primary pt-2"> PHP & mySQL Task Management Project </h2>
              <hr>
            </div>

            <div class="allTask">
              <h3 class="pt-3 text-primary"> All Task </h3>
              <table class="table text-center table-striped table-bordered">
                <tr>
                  <th> #NUMBER  </th>
                  <th> Task Name  </th>
                  <th> Create Date  </th>
                  <th> Take Action  </th>
                </tr>

                <?php
                    $sl = 0;
                    $datas = $taskObj->ShowData();
                    while($outPutData = mysqli_fetch_assoc($datas)){
                ?>

                <tr>
                  <td> <?php echo ++$sl; ?> </td>
                  <td> <?php echo $outPutData['taskname']?> </td>
                  <td> <?php echo $outPutData['taskdate']?> </td>
                  <td> 
                      <a href="edit.php?id=<?php echo $outPutData['id']?>" class="btn btn-sm btn-warning"> EDIT </a>

                      <a href="delete.php?id=<?php echo $outPutData['id']?>" class="btn btn-sm btn-danger"> DELETE </a>
                  </td>
                </tr>

                <?php
                    }
                ?>
                
              </table>
            </div> <!-- ALL TASK END -->

            <!-- ADD TASK -->
            <div class="AddTask">
              <h3 class="pt-3 text-primary"> Add Task </h3>

              <form action="" method="POST" class="form-control mb-4">
                <div class="form-group my-2">
                  <label for="newTask"> Add New Task </label>
                  <input type="text" name="newTask" id="newTask" class="form-control" placeholder="Add New Task" required>
                </div>
                <div class="form-group my-2">
                  <label for="taskDate"> Add Task Date </label>
                  <input type="date" name="taskDate" id="taskDate" class="form-control" required>
                </div>
                <input type="submit" name="taskSubBtn" class="btn my-2 btn-dark" value="Add Task">
              </form>

            </div> <!-- Add TASK END -->

          </div> <!-- col-md-8 offset-md-2 -->
        </div> <!-- Row -->
      </div> <!-- Container -->
    </div>
    
    
  <script type="text/javascript" src="Assets/bootstrap.bundle.min.js"></script>
  </body>
</html>