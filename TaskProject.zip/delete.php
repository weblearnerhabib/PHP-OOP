<?php
require_once('classes/TaskManagement.php');
$taskObj = new TaskManagement;

$id = $_GET['id'];
if(isset($id)){
    $taskObj->DeleteData($id);
    header("location: index.php");
}

?>