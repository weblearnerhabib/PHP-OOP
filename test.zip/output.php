<div class="col-md-6 offset-md-3 shadow pt-3 mt-5">
<table class="table table-bordered table-hover text-center mt-2">
            <thead>
                <tr>
                    <th> Serial No </th>
                    <th> Name </th>
                    <th> Age </th>
                    <th> Action </th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $data = $objMe->ShowData();
                $sl = 0;
                while($value = mysqli_fetch_assoc($data)){
                ?>
                <tr>
                    <td> <?php echo "100". ++$sl?> </td>
                    <td> <?php echo $value['name'] ?> </td>
                    <td> <?php echo $value['age'] ?>  </td>
                    <td>
                        <a href="edit.php?id=<?php echo $value['id'];?>" class="btn btn-sm btn-warning"> Edit </a>
                        <a href="delete.php?id=<?php echo $value['id'];?>" class="btn btn-sm btn-danger"> Delete </a>
                    </td>
                </tr>
                <?php
                }
                ?>
                
            </tbody>
        </table>
    </div>
</div>
</div>