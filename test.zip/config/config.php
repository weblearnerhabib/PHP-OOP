<?php

class DbConnection{
    protected $connection;
    public function __construct(){
         $this->connection = new mysqli("localhost",'root','',"testdbme");
    }
}