<?php
require_once('classes/Class.php');
$objMe = new ClassMe();

$id = $_GET['id'];
if(isset($id)){
   $datas = $objMe->EditData($id);
   $data = mysqli_fetch_assoc($datas);

   if(isset($_POST['upBtn'])){
    $info = $_POST;
    $objMe->UpdateData($info,$id);
   }
}

?>

<?php include_once('header.php');?>
<div class="container">
    <div class="row">
        <div class="col-md-6 offset-md-3 shadow mt-5">
            <form action="" method="POST" class="mt-2">
                <h3 class="text-success text-center py-3"> Update Information </h3>
                <div class="form-group my-3">
                    <input type="text" required name="uname" class="form-control" value="<?php echo $data['name']?>">
                </div>
                <div class="form-group my-3">
                    <input type="text" required name="uage" class="form-control" value="<?php echo $data['age']?>">
                </div>
                <div class="form-group my-3">
                    <input type="password" required name="upass" class="form-control"value="<?php echo $data['password']?>">
                </div>
                <div class="form-group my-3">
                    <input type="submit" name="upBtn" class="btn btn-success btn-lg" value="Update Info">
                </div>
            </form>
        </div>
<?php include_once('footer.php');?>