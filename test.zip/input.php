<div class="container">
    <div class="row">
        <div class="col-md-6 offset-md-3 shadow mt-5">
            <form action="" method="POST" class="mt-2">
                <h3 class="text-success text-center py-3"> Demo Crud Operation Using OOP </h3>
                <div class="form-group my-3">
                    <input type="text" required name="name" class="form-control" placeholder="Type Name">
                </div>
                <div class="form-group my-3">
                    <input type="text" required name="age" class="form-control" placeholder="Type Age">
                </div>
                <div class="form-group my-3">
                    <input type="password" required name="pass" class="form-control" placeholder="Type Password">
                </div>
                <div class="form-group my-3">
                    <input type="submit" name="subBtn" class="btn btn-success btn-lg">
                </div>
            </form>
        </div>