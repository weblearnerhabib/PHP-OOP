<?php
require_once('classes/Class.php');
$objMe = new ClassMe();

if(isset($_POST['subBtn'])){
    $data = $_POST;
    $objMe->InsertData($data);
}


?>

<?php include_once('header.php');?>


        <?php include_once('input.php');?>

        <?php include_once('output.php');?>
       

<?php include_once('footer.php');?>