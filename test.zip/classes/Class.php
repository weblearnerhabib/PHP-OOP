<?php
require_once('config/config.php');
class ClassMe extends DbConnection{

    public function InsertData($receive){
        $name =$receive['name'];
        $age =$receive['age'];
        $pass =$receive['pass'];
        $sql = "INSERT INTO `testtable` (`name`, `age`, `password`) VALUES ('$name', '$age', '$pass')";
        $query = $this->connection->query($sql);
        if($query){
            header("location:index.php");
        }
    }

    public function ShowData(){
        $sql = "SELECT * FROM `testtable`";
        return $query = $this->connection->query($sql);
    }

    public function DeleteData($id){
        $sql = "DELETE FROM `testtable` WHERE id=$id";
        $query = $this->connection->query($sql);
        if($query){
            header("location: index.php");
        }
    }

    public function EditData($id){
        $sql = "SELECT * FROM `testtable` WHERE id=$id";
        return $this->connection->query($sql);
    }

    public function UpdateData($info,$uid){
        $name = $info['uname'];
        $age = $info['uage'];
        $pass = $info['upass'];

        $sql = "UPDATE `testtable` SET `name`='$name',`age`='$age',`password`='$pass' WHERE id = $uid";
        $succ = $this->connection->query($sql);
        if($succ){
            header("location: index.php");
        }
    }
}
?>