<?php
require_once('classes/Class.php');
$objMe = new ClassMe();

$id = $_GET['id'];
if(isset($id)){
    $objMe->DeleteData($id);
}
?>