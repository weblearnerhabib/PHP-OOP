<?php
$con = new mysqli("localhost","root",'','flexiload');

$action = $_POST["action"];
$action();

function add_employee(){
    global $con;

    $number = $_POST['phone'];
    $status = $_POST['status'];
    $amount = $_POST['amount'];
    $date = $_POST['date'];

    $sql = "INSERT INTO `recharge`(`phone`, `operator`, `amount`, `date`) VALUES ('$number','$status','$amount','$date')";

    $insert = $con->query($sql);

    if($insert){
        echo "Data Insert Successfully!";
    }
}

?>