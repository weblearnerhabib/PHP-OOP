// Ajax Jquery
$(document).ready(function(){
    $("#subBtnId").click(function(){
       var customerPhone = $("#customerPhone").val();
       var StatusId = $("#StatusId").val();
       var AmountId = $("#AmountId").val();
       var dateHTML = $("#dateHTML").val();

        $.ajax({
            url: "Classes/Flexiload.php",
            type: "POST",
            data:{
                phone: customerPhone,
                status: StatusId,
                amount: AmountId,
                date: dateHTML,
                action: "add_employee"
            },
            success: function(response){
               $('.sms').html(response).fadeOut(3000);
            }
            
        });

    });
    // submit button end


});