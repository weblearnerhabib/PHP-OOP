<?php


?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tania Mobile Gallery </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
  </head>
  <body>

    <header>
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <img src="https://i.ibb.co/cxjRWn6/mobile.png" alt="" class="img-fluid">
                </div>
            </div>
        </div>
    </header>


    <main>
        <div class="container">
            <div class="row">

                <div class="col-md-8 offset-md-2 mt-4 shadow">
                    <h3 class="text-center pt-3 text-success"> Recharge Details </h3>

                        <h5 class="sms text-warning bg-success text-white"></h5>
                        <div class="form-group">
                            <input required type="number" placeholder="Customer Phone Number" class="form-control my-3" id="customerPhone">
                        </div>

                        <div class="form-group">
                            <select required name="" class="form-control my-3"  id="StatusId">
                                <option value="Default" class="form-control"> Select Operator </option>
                                <option value="Habibur" class="form-control"> Habibur </option>
                                <option value="Rishat" class="form-control"> Rishat </option>
                            </select>
                        </div>

                        <div class="form-group">
                            <input required type="number"  id="AmountId" class="form-control" placeholder="Type Amount">
                        </div>

                        <div class="form-group">
                            <input required type="date"  id="dateHTML" class="form-control my-3">
                        </div>

                        <div class="form-group">
                            <button type="submit" id="subBtnId" class="my-4 btn-success btn"> Insert Flexiload Data </button>
                        </div>
                </div>


            </div>
        </div>

    </main>

    <footer class="mt-5 bg-dark">
        <p class="lead text-center text-white py-2"> Copyright &copy; 2023. Tania Mobile Gallery || All Right Reserved. </p>
    </footer>

    <!-- Jquery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js" integrity="sha512-3gJwYpMe3QewGELv8k/BX9vcqhryRdzRMxVfq6ngyWXwo03GFEzjsUm8Q7RZcHPHksttq7/GFoxjCVUjkjvPdw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- Ajax -->
    <script src="ajax.js"></script>

    <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
  </body>
</html>